function addNumbers(parametr1,  parametr2) {
    let result = parametr1 + parametr2;    
    return result;
}

// let sum = addNumbers(1,2);
let sum = addNumbers(5,6);
console.log(sum);